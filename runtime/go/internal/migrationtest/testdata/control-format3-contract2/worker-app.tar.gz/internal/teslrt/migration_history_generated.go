package teslrt

const teslGeneratedMigrationHistoryJSON = "{\"version\":3,\"kind\":\"compiled-migration-history\",\"compilerAbi\":\"tesl-source-abi-v1:2a00109a022a84309261ac80dc2947f5a4de32384eb5df1c790741e540228855\",\"storedValueCompatibility\":\"tesl-stored-value-v1:12c05146e5164485b878df083a803b23ceedcb16b232268408b1f5de2088de4b\",\"databases\":[{\"database\":\"Lesson84WorkerMigrations.NoteDatabase\",\"family\":\"WorkerNotesSchema\",\"namespace\":\"worker_notes\",\"currentVersion\":1,\"origins\":[{\"initialVersion\":1,\"steps\":[{\"version\":1,\"snapshotHash\":\"e2a40648523d3b8840c76f70bea7da87698ee6187cdd323927a59c0454adc1ad\",\"stepHash\":\"805130621ffe5e11863eb01b4afc67d173ea02ba7461d8f2facbcefa68d37fc1\",\"epochPreserving\":true,\"operations\":[{\"kind\":\"create-table\",\"table\":\"lesson_worker_notes\",\"columns\":[{\"name\":\"id\",\"type\":\"text\",\"nullable\":false,\"primaryKey\":true},{\"name\":\"title\",\"type\":\"text\",\"nullable\":false,\"primaryKey\":false}],\"indexes\":[]}]}],\"errors\":[]}]}]}"

func init() {
	registerCompiledMigrationHistory("Lesson84WorkerMigrations.NoteDatabase", "WorkerNotesSchema", "worker_notes", 1, "tesl-source-abi-v1:2a00109a022a84309261ac80dc2947f5a4de32384eb5df1c790741e540228855", "tesl-stored-value-v1:12c05146e5164485b878df083a803b23ceedcb16b232268408b1f5de2088de4b", teslGeneratedMigrationHistoryJSON)
}
