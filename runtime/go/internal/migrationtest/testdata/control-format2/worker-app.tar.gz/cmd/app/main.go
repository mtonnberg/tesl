package main

import (
	"os"
	"tesl.generated/teslmodlesson84workermigrations/internal/teslmodlesson84workermigrations"
	"tesl.generated/teslmodlesson84workermigrations/internal/teslrt"
)

// The entry point Tesl's `main` describes: its `App { … }` record was lowered into the
// startup chain (activate each queue's workers, then serve), so this is the whole program.
func main() {
	if handled, code := teslrt.RunSchemaCommand(os.Args[1:], os.Stdout, os.Stderr); handled {
		os.Exit(code)
	}
	_ = teslmodlesson84workermigrations.Main()
}
