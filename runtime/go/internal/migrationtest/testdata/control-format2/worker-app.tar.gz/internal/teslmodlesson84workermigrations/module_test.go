package teslmodlesson84workermigrations

import (
	"fmt"
	"os"
	"tesl.generated/teslmodlesson84workermigrations/internal/teslmodworkernotesschemavcurrentnotes"
	"tesl.generated/teslmodlesson84workermigrations/internal/teslrt"
	"testing"
)

func TestMain(teslM *testing.M) {
	_, _ = fmt.Fprintln(os.Stderr, "TESL_GO_TESTS_STARTED")
	testExitCode := teslM.Run()
	os.Exit(testExitCode)
}

func TestTesl0(teslT *testing.T) {
	if teslWanted := os.Getenv("TESL_TEST_NAME"); teslWanted != "" && teslWanted != "schema-owned validation trims a title before storing it" && teslWanted != "TestTesl0" {
		teslT.Skip("named test filter")
	}
	if teslKind := os.Getenv("TESL_TEST_KIND"); teslKind != "" && teslKind != "test" {
		teslT.Skip("test kind filter")
	}
	teslResetTestState()
	defer func() {
		if teslTrap := recover(); teslTrap != nil {
			teslT.Fatalf("Tesl test trapped: %v", teslTrap)
		}
	}()
//line lesson84-worker-migrations.tesl:218
	if !(SaveTitle("first", "  a schema has one owner  ")) {
//line lesson84-worker-migrations.tesl:218
		teslT.Fatal("Tesl expectation failed")
	}
	teslLeft1 := FindTitle("first")
	teslRight1 := teslrt.Maybe[string]{Tag: teslrt.MaybeSomething, SomethingValue: "a schema has one owner"}
//line lesson84-worker-migrations.tesl:219
	if teslLeft1.Tag != teslRight1.Tag || (teslLeft1.Tag == teslrt.MaybeSomething && (teslLeft1.SomethingValue != teslRight1.SomethingValue)) {
//line lesson84-worker-migrations.tesl:219
		teslT.Fatal("Tesl expectation failed")
	}
}

func TestTesl1(teslT *testing.T) {
	if teslWanted := os.Getenv("TESL_TEST_NAME"); teslWanted != "" && teslWanted != "an invalid title does not insert a row" && teslWanted != "TestTesl1" {
		teslT.Skip("named test filter")
	}
	if teslKind := os.Getenv("TESL_TEST_KIND"); teslKind != "" && teslKind != "test" {
		teslT.Skip("test kind filter")
	}
	teslResetTestState()
	defer func() {
		if teslTrap := recover(); teslTrap != nil {
			teslT.Fatalf("Tesl test trapped: %v", teslTrap)
		}
	}()
//line lesson84-worker-migrations.tesl:223
	if SaveTitle("empty", "") {
//line lesson84-worker-migrations.tesl:223
		teslT.Fatal("Tesl expectation failed")
	}
//line lesson84-worker-migrations.tesl:224
	if SaveTitle("spaces", "   ") {
//line lesson84-worker-migrations.tesl:224
		teslT.Fatal("Tesl expectation failed")
	}
	teslLeft2 := FindTitle("empty")
	teslRight2 := teslrt.Maybe[string]{Tag: teslrt.MaybeNothing}
//line lesson84-worker-migrations.tesl:225
	if teslLeft2.Tag != teslRight2.Tag || (teslLeft2.Tag == teslrt.MaybeSomething && (teslLeft2.SomethingValue != teslRight2.SomethingValue)) {
//line lesson84-worker-migrations.tesl:225
		teslT.Fatal("Tesl expectation failed")
	}
	teslLeft3 := FindTitle("spaces")
	teslRight3 := teslrt.Maybe[string]{Tag: teslrt.MaybeNothing}
//line lesson84-worker-migrations.tesl:226
	if teslLeft3.Tag != teslRight3.Tag || (teslLeft3.Tag == teslrt.MaybeSomething && (teslLeft3.SomethingValue != teslRight3.SomethingValue)) {
//line lesson84-worker-migrations.tesl:226
		teslT.Fatal("Tesl expectation failed")
	}
}

func TestTesl2(teslT *testing.T) {
	if teslWanted := os.Getenv("TESL_TEST_NAME"); teslWanted != "" && teslWanted != "the private schema helper defines the accepted title boundary" && teslWanted != "TestTesl2" {
		teslT.Skip("named test filter")
	}
	if teslKind := os.Getenv("TESL_TEST_KIND"); teslKind != "" && teslKind != "test" {
		teslT.Skip("test kind filter")
	}
	teslResetTestState()
	defer func() {
		if teslTrap := recover(); teslTrap != nil {
			teslT.Fatalf("Tesl test trapped: %v", teslTrap)
		}
	}()
	{
//line lesson84-worker-migrations.tesl:230
		limit := teslrt.StringRepeat("x", teslrt.FromInt64(80))
		_ = limit
		{
//line lesson84-worker-migrations.tesl:231
			overLimit := teslrt.StringRepeat("x", teslrt.FromInt64(81))
			_ = overLimit
//line lesson84-worker-migrations.tesl:232
			if !(SaveTitle("limit", limit)) {
//line lesson84-worker-migrations.tesl:232
				teslT.Fatal("Tesl expectation failed")
			}
			teslLeft4 := FindTitle("limit")
			teslRight4 := teslrt.Maybe[string]{Tag: teslrt.MaybeSomething, SomethingValue: limit}
//line lesson84-worker-migrations.tesl:233
			if teslLeft4.Tag != teslRight4.Tag || (teslLeft4.Tag == teslrt.MaybeSomething && (teslLeft4.SomethingValue != teslRight4.SomethingValue)) {
//line lesson84-worker-migrations.tesl:233
				teslT.Fatal("Tesl expectation failed")
			}
//line lesson84-worker-migrations.tesl:234
			if SaveTitle("too-long", overLimit) {
//line lesson84-worker-migrations.tesl:234
				teslT.Fatal("Tesl expectation failed")
			}
			teslLeft5 := FindTitle("too-long")
			teslRight5 := teslrt.Maybe[string]{Tag: teslrt.MaybeNothing}
//line lesson84-worker-migrations.tesl:235
			if teslLeft5.Tag != teslRight5.Tag || (teslLeft5.Tag == teslrt.MaybeSomething && (teslLeft5.SomethingValue != teslRight5.SomethingValue)) {
//line lesson84-worker-migrations.tesl:235
				teslT.Fatal("Tesl expectation failed")
			}
		}
	}
}

func TestTesl3(teslT *testing.T) {
	if teslWanted := os.Getenv("TESL_TEST_NAME"); teslWanted != "" && teslWanted != "validation and storage preserve Unicode titles" && teslWanted != "TestTesl3" {
		teslT.Skip("named test filter")
	}
	if teslKind := os.Getenv("TESL_TEST_KIND"); teslKind != "" && teslKind != "test" {
		teslT.Skip("test kind filter")
	}
	teslResetTestState()
	defer func() {
		if teslTrap := recover(); teslTrap != nil {
			teslT.Fatalf("Tesl test trapped: %v", teslTrap)
		}
	}()
//line lesson84-worker-migrations.tesl:239
	if !(SaveTitle("unicode", "  \xc3\x84ndra schemat  ")) {
//line lesson84-worker-migrations.tesl:239
		teslT.Fatal("Tesl expectation failed")
	}
	teslLeft6 := FindTitle("unicode")
	teslRight6 := teslrt.Maybe[string]{Tag: teslrt.MaybeSomething, SomethingValue: "\xc3\x84ndra schemat"}
//line lesson84-worker-migrations.tesl:240
	if teslLeft6.Tag != teslRight6.Tag || (teslLeft6.Tag == teslrt.MaybeSomething && (teslLeft6.SomethingValue != teslRight6.SomethingValue)) {
//line lesson84-worker-migrations.tesl:240
		teslT.Fatal("Tesl expectation failed")
	}
}

func TestTesl4(teslT *testing.T) {
	if teslWanted := os.Getenv("TESL_TEST_NAME"); teslWanted != "" && teslWanted != "a missing row stays missing" && teslWanted != "TestTesl4" {
		teslT.Skip("named test filter")
	}
	if teslKind := os.Getenv("TESL_TEST_KIND"); teslKind != "" && teslKind != "test" {
		teslT.Skip("test kind filter")
	}
	teslResetTestState()
	defer func() {
		if teslTrap := recover(); teslTrap != nil {
			teslT.Fatalf("Tesl test trapped: %v", teslTrap)
		}
	}()
	teslLeft7 := FindTitle("never-written")
	teslRight7 := teslrt.Maybe[string]{Tag: teslrt.MaybeNothing}
//line lesson84-worker-migrations.tesl:244
	if teslLeft7.Tag != teslRight7.Tag || (teslLeft7.Tag == teslrt.MaybeSomething && (teslLeft7.SomethingValue != teslRight7.SomethingValue)) {
//line lesson84-worker-migrations.tesl:244
		teslT.Fatal("Tesl expectation failed")
	}
}

// api-test the full app creates and retrieves a normalized note
//
//line lesson84-worker-migrations.tesl:189
func TestTeslApi0(teslT *testing.T) {
	if teslWanted := os.Getenv("TESL_TEST_NAME"); teslWanted != "" && teslWanted != "the full app creates and retrieves a normalized note" && teslWanted != "TestTeslApi0" {
		teslT.Skip("named test filter")
	}
	if teslKind := os.Getenv("TESL_TEST_KIND"); teslKind != "" && teslKind != "api-test" {
		teslT.Skip("test kind filter")
	}
	teslResetTestState()
	defer func() {
		if teslTrap := recover(); teslTrap != nil {
			teslT.Fatalf("Tesl test trapped: %v", teslTrap)
		}
	}()
	{
//line lesson84-worker-migrations.tesl:190
		created := teslrt.ApiRequest(NotesServer, "POST", "/notes/first", "{\"title\":\"  First note  \"}", nil, nil)
		_ = created
//line lesson84-worker-migrations.tesl:191
		if !(teslrt.StatusOk(created.Status)) {
//line lesson84-worker-migrations.tesl:191
			teslT.Fatal("Tesl expectation failed")
		}
//line lesson84-worker-migrations.tesl:192
		if !teslrt.JsonEqual(created.Body, teslrt.JsonParseBody("{\"id\":\"first\",\"title\":\"First note\"}").JsonRaw()) {
//line lesson84-worker-migrations.tesl:192
			teslT.Fatal("Tesl expectation failed")
		}
		{
//line lesson84-worker-migrations.tesl:193
			fetched := teslrt.ApiRequest(NotesServer, "GET", "/notes/first", "", nil, nil)
			_ = fetched
			teslLeft8 := fetched.Status
//line lesson84-worker-migrations.tesl:194
			if !teslrt.Equal(teslLeft8, teslrt.FromInt64(200)) {
//line lesson84-worker-migrations.tesl:194
				teslT.Fatal("Tesl expectation failed")
			}
//line lesson84-worker-migrations.tesl:195
			if !teslrt.JsonEqual(fetched.Body, created.Body) {
//line lesson84-worker-migrations.tesl:195
				teslT.Fatal("Tesl expectation failed")
			}
		}
	}
}

// api-test invalid input fails without creating a note
//
//line lesson84-worker-migrations.tesl:198
func TestTeslApi1(teslT *testing.T) {
	if teslWanted := os.Getenv("TESL_TEST_NAME"); teslWanted != "" && teslWanted != "invalid input fails without creating a note" && teslWanted != "TestTeslApi1" {
		teslT.Skip("named test filter")
	}
	if teslKind := os.Getenv("TESL_TEST_KIND"); teslKind != "" && teslKind != "api-test" {
		teslT.Skip("test kind filter")
	}
	teslResetTestState()
	defer func() {
		if teslTrap := recover(); teslTrap != nil {
			teslT.Fatalf("Tesl test trapped: %v", teslTrap)
		}
	}()
	{
//line lesson84-worker-migrations.tesl:199
		rejected := teslrt.ApiRequest(NotesServer, "POST", "/notes/invalid", "{\"title\":\"   \"}", nil, nil)
		_ = rejected
		teslLeft9 := rejected.Status
//line lesson84-worker-migrations.tesl:200
		if !teslrt.Equal(teslLeft9, teslrt.FromInt64(400)) {
//line lesson84-worker-migrations.tesl:200
			teslT.Fatal("Tesl expectation failed")
		}
		{
//line lesson84-worker-migrations.tesl:201
			missing := teslrt.ApiRequest(NotesServer, "GET", "/notes/invalid", "", nil, nil)
			_ = missing
			teslLeft10 := missing.Status
//line lesson84-worker-migrations.tesl:202
			if !teslrt.Equal(teslLeft10, teslrt.FromInt64(404)) {
//line lesson84-worker-migrations.tesl:202
				teslT.Fatal("Tesl expectation failed")
			}
		}
	}
}

// api-test a malformed request never reaches storage
//
//line lesson84-worker-migrations.tesl:205
func TestTeslApi2(teslT *testing.T) {
	if teslWanted := os.Getenv("TESL_TEST_NAME"); teslWanted != "" && teslWanted != "a malformed request never reaches storage" && teslWanted != "TestTeslApi2" {
		teslT.Skip("named test filter")
	}
	if teslKind := os.Getenv("TESL_TEST_KIND"); teslKind != "" && teslKind != "api-test" {
		teslT.Skip("test kind filter")
	}
	teslResetTestState()
	defer func() {
		if teslTrap := recover(); teslTrap != nil {
			teslT.Fatalf("Tesl test trapped: %v", teslTrap)
		}
	}()
	{
//line lesson84-worker-migrations.tesl:206
		rejected := teslrt.ApiRequest(NotesServer, "POST", "/notes/malformed", "{\"title\":42}", nil, nil)
		_ = rejected
		teslLeft11 := rejected.Status
//line lesson84-worker-migrations.tesl:207
		if !teslrt.Equal(teslLeft11, teslrt.FromInt64(400)) {
//line lesson84-worker-migrations.tesl:207
			teslT.Fatal("Tesl expectation failed")
		}
		{
//line lesson84-worker-migrations.tesl:208
			missing := teslrt.ApiRequest(NotesServer, "GET", "/notes/malformed", "", nil, nil)
			_ = missing
			teslLeft12 := missing.Status
//line lesson84-worker-migrations.tesl:209
			if !teslrt.Equal(teslLeft12, teslrt.FromInt64(404)) {
//line lesson84-worker-migrations.tesl:209
				teslT.Fatal("Tesl expectation failed")
			}
		}
	}
}

// api-test a new test starts with an empty database
//
//line lesson84-worker-migrations.tesl:212
func TestTeslApi3(teslT *testing.T) {
	if teslWanted := os.Getenv("TESL_TEST_NAME"); teslWanted != "" && teslWanted != "a new test starts with an empty database" && teslWanted != "TestTeslApi3" {
		teslT.Skip("named test filter")
	}
	if teslKind := os.Getenv("TESL_TEST_KIND"); teslKind != "" && teslKind != "api-test" {
		teslT.Skip("test kind filter")
	}
	teslResetTestState()
	defer func() {
		if teslTrap := recover(); teslTrap != nil {
			teslT.Fatalf("Tesl test trapped: %v", teslTrap)
		}
	}()
	{
//line lesson84-worker-migrations.tesl:213
		missing := teslrt.ApiRequest(NotesServer, "GET", "/notes/first", "", nil, nil)
		_ = missing
		teslLeft13 := missing.Status
//line lesson84-worker-migrations.tesl:214
		if !teslrt.Equal(teslLeft13, teslrt.FromInt64(404)) {
//line lesson84-worker-migrations.tesl:214
			teslT.Fatal("Tesl expectation failed")
		}
	}
}

// teslResetTestState empties the stores every test block starts from, so no block
// inherits another's rows, jobs, or outbound-HTTP stubs.
func teslResetTestState() {
	teslrt.TableTruncate(teslmodworkernotesschemavcurrentnotes.NoteTable)
}
