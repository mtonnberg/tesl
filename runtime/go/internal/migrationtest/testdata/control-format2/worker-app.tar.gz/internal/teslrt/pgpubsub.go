package teslrt

import (
	"context"
	"errors"
	"fmt"
	"os"
	goruntime "runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v5"
)

// Cross-instance SSE pub/sub on PostgreSQL: `sseChannel C(key) = SseChannel { database: D … }`.
//
// A publish delivered only to the listeners of THIS process reaches a browser subscribed on
// another replica never: with two instances behind a load balancer, half the events vanish.
// The spec (§ SSE channels) promises what this file implements — a `tesl_pubsub_outbox` table
// created alongside the entity tables, events published inside `transaction { }` written to
// it atomically and delivered after commit, and one PostgreSQL LISTEN connection per process
// for the fan-out. The retired Racket runtime (`tesl/queue.rkt`) did the same, and its two
// hard-won rules are kept: a NOTIFY carries the outbox ROW ID rather than the payload (every
// instance SELECTs the same row, so nothing is lost to the 8000-byte NOTIFY limit), and a
// periodic SWEEP re-reads the outbox so a lost notification or a reconnecting instance still
// delivers everything.
//
// WHAT DIFFERS FROM RACKET, deliberately. Racket delivered the publisher's own event locally
// after commit and marked the row so the LISTEN path would skip it; here the publisher's own
// process receives its events through the SAME LISTEN path as every other instance. One path
// instead of two means one ordering (the outbox's), no per-process "already delivered" set
// that must stay consistent with the deferred-delivery list, and the rolled-back case falls
// out for free: a row that never committed fires no NOTIFY and is visible to no sweep.
//
// WHERE THE FILE SHIPS. Only with a Postgres-backed program — it is the one place the SSE
// channel meets `*Database` and pgx, and sse.go (always shipped) sees it only through the
// `pubsubBackend` interface. A channel of a Memory-backed database never touches this file.
//
// COMMIT-ORDERED DISPATCH. The row id is allocated by INSERT, not commit, so it is never used
// as a lifetime delivery cursor. A publisher takes one transaction-scoped advisory lock before
// drawing dispatch_seq and holds it through commit. Publishers therefore commit in sequence
// order. The delivery loop reads only that order; NOTIFY is a doorbell, never a delivery path.
//
// STARTUP BASELINE. A process does not replay old SSE events. PostgreSQL bootstrap upgrades all
// visible rows from the former nullable-sequence format before a runtime captures max
// (dispatch_seq). A legacy transaction that commits later remains NULL and the delivery loop
// safely sequences it above the baseline under the same advisory lock.

const (
	pubsubNotifyChannel = "tesl_pubsub"
	// queueNotifyChannel carries the QUEUE NAME as payload: one channel for every queue on the
	// database, so the listener connection is shared, and the payload says whose doorbell to
	// ring.
	queueNotifyChannel = "tesl_queue"
	pubsubOutboxTable  = "tesl_pubsub_outbox"
	pubsubDispatchSeq  = "tesl_pubsub_dispatch_seq"
	// pubsubSweepBatch bounds every dispatch and delivery query. A full batch yields and runs
	// again immediately, so memory and query work are bounded without throttling catch-up.
	pubsubSweepBatch = 500
)

// The intervals are variables so a test can shrink them; production never writes them.
var (
	// pubsubSweepInterval is how often the outbox is re-read for rows a notification missed.
	pubsubSweepInterval = 5 * time.Second
	// pubsubBindPollInterval is how often an idle backend checks whether its database has
	// been bound yet: the listener cannot start before `with database D`.
	pubsubBindPollInterval = 250 * time.Millisecond
	// The reconnect backoff after the LISTEN connection drops, doubling up to the maximum.
	pubsubReconnectMinBackoff = 200 * time.Millisecond
	pubsubReconnectMaxBackoff = 5 * time.Second
	// pubsubOutboxRetention is how long a delivered row stays before a sweep prunes it.
	pubsubOutboxRetention = time.Hour
	pubsubPruneInterval   = time.Minute
)

// pgPubsub is one process's pub/sub state for one `Database` declaration: the channels
// declared on it and its single ordered LISTEN/delivery goroutine.
type pgPubsub struct {
	database *Database

	mutex sync.Mutex
	// channels by declared NAME. A name normally has one channel; a test standing two
	// channels in for two instances registers two, and both receive.
	channels map[string][]*SseChannel
	// queues by declared name, woken on a `tesl_queue` notification naming them.
	queues map[string][]*Queue
	// ready is set once the outbox table exists and the dispatch baseline is captured.
	ready bool
	// dispatchCursor is the highest commit-ordered dispatch sequence this process delivered.
	dispatchCursor int64
	// deliveryMutex keeps manual/test catch-up calls serialized with the listener. Production
	// has only the listener path, but making the invariant local prevents future double delivery.
	deliveryMutex sync.Mutex
	// listener is the live LISTEN connection, or nil between connections.
	listener *pgx.Conn

	ctx    context.Context
	cancel context.CancelFunc
	done   chan struct{}
}

// pgPubsubs is the per-database registry: one runtime per `Database` value, created by the
// first `NewSseChannelOn` naming it.
var pgPubsubs sync.Map // *Database -> *pgPubsub

// NewSseChannelOn is what an `sseChannel` declaration with `database: D` emits, where
// `NewSseChannel` is what a Memory-backed one emits. The channel is an ordinary SseChannel
// with the database's pub/sub runtime attached, and registered with that runtime under its
// name so an event arriving from another instance finds it.
func NewSseChannelOn(database *Database, name string) *SseChannel {
	pgRegisterMigrationFacility(database, "SSE channel", name)
	channel := NewSseChannel(name)
	runtime := pubsubFor(database)
	runtime.mutex.Lock()
	runtime.channels[name] = append(runtime.channels[name], channel)
	runtime.mutex.Unlock()
	channel.backend = runtime
	return channel
}

// registerQueue hands a durable queue's doorbell to the database's listener.
func (runtime *pgPubsub) registerQueue(queue *Queue) {
	runtime.mutex.Lock()
	runtime.queues[queue.name] = append(runtime.queues[queue.name], queue)
	runtime.mutex.Unlock()
}

// wakeQueues rings every registered queue named by a `tesl_queue` notification.
func (runtime *pgPubsub) wakeQueues(name string) {
	runtime.mutex.Lock()
	queues := append([]*Queue(nil), runtime.queues[name]...)
	runtime.mutex.Unlock()
	for _, queue := range queues {
		queue.Wake()
	}
}

func pubsubFor(database *Database) *pgPubsub {
	if existing, found := pgPubsubs.Load(database); found {
		if runtime, ok := existing.(*pgPubsub); ok {
			return runtime
		}
	}
	ctx, cancel := context.WithCancel(context.Background())
	created := &pgPubsub{
		database: database,
		channels: map[string][]*SseChannel{},
		queues:   map[string][]*Queue{},
		ctx:      ctx,
		cancel:   cancel,
		done:     make(chan struct{}),
	}
	actual, loaded := pgPubsubs.LoadOrStore(database, created)
	if loaded {
		cancel()
		if runtime, ok := actual.(*pgPubsub); ok {
			return runtime
		}
	}
	go created.run()
	return created
}

// ── The publish side ──────────────────────────────────────────────────────────

// active answers whether the database is bound. It also captures the baseline on the current
// executor, so a first publish inside a pool-size-one transaction never asks the pool for a
// second connection.
func (runtime *pgPubsub) active() bool {
	connection := runtime.database.bound()
	if connection == nil {
		return false
	}
	if err := runtime.prepare(connection); err != nil {
		panic(pgFailure("publish: cannot prepare the pub/sub outbox", err))
	}
	return true
}

// publish takes the outbox lock, allocates dispatch_seq, writes the row, and queues NOTIFY in
// one transaction. If the caller already has a transaction, the lock remains held until that
// transaction commits; otherwise this method opens the transaction itself.
func (runtime *pgPubsub) publish(channel, key string, encoded string) {
	connection := runtime.database.bound()
	if connection == nil {
		// The binding ended between `active` and here, which only a concurrent unbind can
		// do; the event is still owed to this process's listeners.
		runtime.deliver(channel, key, encoded)
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), pgLeaseTimeout())
	defer cancel()
	if transaction := currentTransactionFor(connection); transaction != nil {
		if err := pgAdmitMigrationTransaction(ctx, transaction, connection, true); err != nil {
			panic(pgFailure("publish", err))
		}
		if _, err := writePubsub(ctx, transaction, connection, channel, key, encoded); err != nil {
			panic(pgFailure("publish", err))
		}
	} else {
		options := pgx.TxOptions{}
		if connection.migration != nil {
			options.IsoLevel = pgx.ReadCommitted
		}
		transaction, err := connection.pool.BeginTx(ctx, options)
		if err != nil {
			panic(pgFailure("publish: cannot begin", err))
		}
		committed := false
		defer func() {
			if !committed {
				_ = transaction.Rollback(context.Background())
			}
		}()
		if err := pgAdmitMigrationTransaction(ctx, transaction, connection, true); err != nil {
			panic(pgFailure("publish", err))
		}
		if _, err := writePubsub(ctx, transaction, connection, channel, key, encoded); err != nil {
			panic(pgFailure("publish", err))
		}
		if err := transaction.Commit(ctx); err != nil {
			panic(pgFailure("publish: cannot commit", err))
		}
		committed = true
	}
	Counter("tesl.sse.pubsub.published", FromInt64(1), sseChannelAttribute(channel))
}

func writePubsub(ctx context.Context, executor pgExecutor, connection *PostgresDB,
	channel, key, encoded string) (int64, error) {
	if err := pgVerifyMigrationFacilityConnection(connection, "SSE outbox"); err != nil {
		return 0, err
	}
	if _, err := executor.Exec(ctx,
		`select pg_advisory_xact_lock(hashtextextended(current_database() || ':' || $1, 0))`,
		connection.QualifiedTable(pubsubOutboxTable)); err != nil {
		return 0, err
	}
	var id int64
	err := executor.QueryRow(ctx, "insert into "+connection.QualifiedTable(pubsubOutboxTable)+
		` ("channel", "key", "payload", "dispatch_seq", "dispatched_at") `+
		`values ($1, $2, $3::jsonb, nextval($4::regclass), clock_timestamp()) returning "id"`,
		channel, key, encoded, connection.QualifiedTable(pubsubDispatchSeq)).Scan(&id)
	if err != nil {
		return 0, err
	}
	if _, err := executor.Exec(ctx, "select pg_notify($1, $2)",
		pubsubNotifyChannel, strconv.FormatInt(id, 10)); err != nil {
		return 0, err
	}
	return id, nil
}

// prepare captures the committed dispatch baseline once per runtime. Bootstrap owns the DDL
// and legacy normalization, so this read is safe through a caller's existing transaction.
func (runtime *pgPubsub) prepare(connection *PostgresDB) error {
	return runtime.prepareOn(connection, connection.executor())
}

func (runtime *pgPubsub) prepareOn(connection *PostgresDB, executor pgExecutor) error {
	if err := pgVerifyMigrationFacilityConnection(connection, "SSE outbox"); err != nil {
		return err
	}
	runtime.mutex.Lock()
	defer runtime.mutex.Unlock()
	if runtime.ready {
		return nil
	}
	ctx, cancel := context.WithTimeout(context.Background(), pgLeaseTimeout())
	defer cancel()
	cursor, err := pgMigrationStatementOn(ctx, connection, executor, false, func(executor pgExecutor) (int64, error) {
		var cursor int64
		err := executor.QueryRow(ctx, `select coalesce(max("dispatch_seq"), 0) from `+connection.QualifiedTable(pubsubOutboxTable)).Scan(&cursor)
		return cursor, err
	})
	if err != nil {
		return err
	}
	runtime.dispatchCursor = cursor

	runtime.ready = true
	return nil
}

// createPubsubOutbox owns only Tesl's runtime table, sequence, and indexes. The ALTERs are the
// idempotent upgrade from the original allocation-ordered outbox; they are not application
// schema migration machinery.
func createPubsubOutbox(ctx context.Context, connection *PostgresDB) error {
	if err := pgVerifyMigrationFacilityConnection(connection, "SSE outbox"); err != nil {
		return err
	}
	table := connection.QualifiedTable(pubsubOutboxTable)
	statements := []string{
		`create sequence if not exists ` + connection.QualifiedTable(pubsubDispatchSeq),
		fmt.Sprintf(`create table if not exists %s (
	"id" bigserial primary key,
	"channel" text not null,
	"key" text not null,
	"payload" jsonb not null,
	"created_at" timestamptz not null default now(),
	"dispatch_seq" bigint,
	"dispatched_at" timestamptz
)`, table),
		`alter table ` + table + ` add column if not exists "dispatch_seq" bigint`,
		`alter table ` + table + ` add column if not exists "dispatched_at" timestamptz`,
		`create unique index if not exists ` + quoteIdentifier(pubsubOutboxTable+"_dispatch_idx") +
			` on ` + table + ` ("dispatch_seq") where "dispatch_seq" is not null`,
		`create index if not exists ` + quoteIdentifier(pubsubOutboxTable+"_pending_idx") +
			` on ` + table + ` ("id") where "dispatch_seq" is null`,
		`create index if not exists ` + quoteIdentifier(pubsubOutboxTable+"_prune_idx") +
			` on ` + table + ` ("dispatched_at") where "dispatched_at" is not null`,
	}
	for _, statement := range statements {
		var err error
		for attempt := 0; attempt < 2; attempt++ {
			if _, err = connection.pool.Exec(ctx, statement); err == nil {
				break
			}
			if !pgDuplicateObject(err) && !strings.Contains(err.Error(), "already exists") {
				return err
			}
		}
		if err != nil {
			return err
		}
	}
	return nil
}

// normalizeLegacyPubsubRows runs during PostgreSQL bootstrap, before the Database can be bound
// and before a runtime captures its baseline. Each transaction has a fresh lease and handles a
// bounded batch, avoiding the old single 10-second context across an arbitrarily large outbox.
func normalizeLegacyPubsubRows(connection *PostgresDB) error {
	if err := pgVerifyMigrationFacilityConnection(connection, "SSE outbox"); err != nil {
		return err
	}
	for {
		ctx, cancel := context.WithTimeout(context.Background(), pgLeaseTimeout())
		dispatched, err := dispatchLegacyPubsubPending(ctx, connection.pool, connection)
		cancel()
		if err != nil {
			return err
		}
		if dispatched < pubsubSweepBatch {
			return nil
		}
		goruntime.Gosched()
	}
}

// ── The delivery side ─────────────────────────────────────────────────────────

// deliver hands one stored event to every local channel of that name. A payload that does
// not parse is a row another tool wrote, and is skipped rather than allowed to end the
// listener.
func (runtime *pgPubsub) deliver(channel, key string, encoded string) {
	payload, err := ParseJSON([]byte(encoded))
	if err != nil {
		fmt.Fprintf(os.Stderr, "tesl: pubsub: outbox row on channel %s holds no JSON: %v\n",
			channel, err)
		return
	}
	runtime.mutex.Lock()
	targets := append([]*SseChannel{}, runtime.channels[channel]...)
	runtime.mutex.Unlock()
	for _, target := range targets {
		deliverLocal(target, key, payload)
	}
}

func (runtime *pgPubsub) cursor() int64 {
	runtime.mutex.Lock()
	defer runtime.mutex.Unlock()
	return runtime.dispatchCursor
}

func (runtime *pgPubsub) advance(dispatchSequence int64) {
	runtime.mutex.Lock()
	defer runtime.mutex.Unlock()
	if dispatchSequence > runtime.dispatchCursor {
		runtime.dispatchCursor = dispatchSequence
	}
}

// run is the listener goroutine: wait for the database to be bound, then hold a LISTEN
// connection for as long as the process lives, reconnecting with backoff when it drops.
func (runtime *pgPubsub) run() {
	defer close(runtime.done)
	backoff := pubsubReconnectMinBackoff
	for {
		connection := runtime.database.bound()
		if connection == nil {
			if !runtime.pause(pubsubBindPollInterval) {
				return
			}
			continue
		}
		listened, err := runtime.listenGuarded(connection)
		if listened {
			backoff = pubsubReconnectMinBackoff
		}
		if runtime.ctx.Err() != nil {
			return
		}
		if err != nil {
			fmt.Fprintf(os.Stderr, "tesl: pubsub: listener on database %s: %v (reconnecting in %s)\n",
				runtime.database.Name, err, backoff)
		}
		if !runtime.pause(backoff) {
			return
		}
		backoff = min(backoff*2, pubsubReconnectMaxBackoff)
	}
}

// listenGuarded is one connection attempt with any TRAP inside it turned into the error the
// reconnect loop already handles. The listener goroutine is the
// process's only path from other instances' events to its subscribers; an unrecovered panic
// in it (a decode that traps, a driver surprise) would end the whole process rather than
// one connection.
func (runtime *pgPubsub) listenGuarded(connection *PostgresDB) (listened bool, err error) {
	defer func() {
		if trap := recover(); trap != nil {
			listened, err = false, fmt.Errorf("listener trapped: %v", trap)
		}
	}()
	return runtime.listen(connection)
}

// pause sleeps, or answers false if the runtime was closed meanwhile.
func (runtime *pgPubsub) pause(duration time.Duration) bool {
	timer := time.NewTimer(duration)
	defer timer.Stop()
	select {
	case <-runtime.ctx.Done():
		return false
	case <-timer.C:
		return true
	}
}

// listen holds ONE dedicated connection: LISTEN, an immediate catch-up sweep, then a loop
// that waits for a notification and, when none arrives within the sweep interval, sweeps.
// Everything runs on that one connection and one goroutine — a pool lease is never spent on
// delivery, so a saturated pool delays requests, not events.
//
// The connection is opened from the pool's configuration rather than leased from the pool:
// a connection that has issued LISTEN must never be handed to another statement, and it
// lives for the process, which is not what a pool's connections are for. `listened` reports
// whether LISTEN was established, which is what resets the reconnect backoff.
func (runtime *pgPubsub) listen(connection *PostgresDB) (listened bool, err error) {
	if err := pgVerifyMigrationFacilityConnection(connection, "SSE listener"); err != nil {
		return false, err
	}
	connectCtx, cancelConnect := context.WithTimeout(runtime.ctx, pgLeaseTimeout())
	defer cancelConnect()
	conn, err := pgx.ConnectConfig(connectCtx, connection.pool.Config().ConnConfig.Copy())
	if err != nil {
		return false, err
	}
	defer func() {
		closeCtx, cancelClose := context.WithTimeout(context.Background(), pgLeaseTimeout())
		defer cancelClose()
		_ = conn.Close(closeCtx)
		runtime.mutex.Lock()
		runtime.listener = nil
		runtime.mutex.Unlock()
	}()
	if err := pgVerifyMigrationConnection(connectCtx, conn, connection); err != nil {
		return false, err
	}
	if err := runtime.prepareOn(connection, conn); err != nil {
		return false, err
	}
	if _, err := conn.Exec(connectCtx, "listen "+quoteIdentifier(pubsubNotifyChannel)); err != nil {
		return false, err
	}
	if _, err := conn.Exec(connectCtx, "listen "+quoteIdentifier(queueNotifyChannel)); err != nil {
		return false, err
	}
	runtime.mutex.Lock()
	runtime.listener = conn
	runtime.mutex.Unlock()

	// Rows that committed before LISTEN was in place, and rows a previous connection's
	// last moments missed.
	if err := runtime.drain(conn, connection); err != nil {
		return true, err
	}
	nextSweep := time.Now().Add(pubsubSweepInterval)
	nextPrune := time.Now().Add(pubsubPruneInterval)
	for {
		waitCtx, cancelWait := context.WithDeadline(runtime.ctx, nextSweep)
		notification, err := conn.WaitForNotification(waitCtx)
		cancelWait()
		switch {
		case err == nil:
			now := time.Now()
			if notification != nil && notification.Channel == queueNotifyChannel {
				runtime.wakeQueues(notification.Payload)
			} else if notification != nil && notification.Channel == pubsubNotifyChannel {
				// The payload is deliberately ignored. NOTIFY only wakes the same durable,
				// ordered path used for reconnect and lost-notification recovery.
				if err := runtime.drain(conn, connection); err != nil {
					return true, err
				}
				nextSweep = now.Add(pubsubSweepInterval)
			}
			if !now.Before(nextSweep) {
				if err := runtime.drain(conn, connection); err != nil {
					return true, err
				}
				nextSweep = now.Add(pubsubSweepInterval)
			}
			if !now.Before(nextPrune) {
				if err := runtime.prune(conn, connection); err != nil {
					return true, err
				}
				nextPrune = now.Add(pubsubPruneInterval)
			}
			continue
		case errors.Is(err, context.DeadlineExceeded) && runtime.ctx.Err() == nil:
			// The wait ran out, which is the sweep's cue; the connection is intact — pgx
			// resets the read deadline on the way out, and a deadline is not a fatal error
			// to it.
			if err := runtime.drain(conn, connection); err != nil {
				return true, err
			}
			nextSweep = time.Now().Add(pubsubSweepInterval)
			if !time.Now().Before(nextPrune) {
				if err := runtime.prune(conn, connection); err != nil {
					return true, err
				}
				nextPrune = time.Now().Add(pubsubPruneInterval)
			}
		default:
			return true, err
		}
	}
}

type pubsubRow struct {
	id               int64
	dispatchSequence int64
	channel, key     string
	encoded          string
}

type pgTransactionStarter interface {
	Begin(context.Context) (pgx.Tx, error)
}

// dispatchLegacyPubsubPending upgrades one bounded batch written by the former nullable-sequence
// format. The explicit transaction makes the ordering proof the same as Publish: take the lock,
// draw sequence values, and commit before another cooperating publisher can draw one.
func dispatchLegacyPubsubPending(ctx context.Context, starter pgTransactionStarter,
	connection *PostgresDB) (int, error) {
	var transaction pgx.Tx
	var err error
	if connection.migration == nil {
		transaction, err = starter.Begin(ctx)
	} else {
		capable, ok := starter.(pgMigrationTransactionStarter)
		if !ok {
			return 0, fmt.Errorf("migration dispatch requires a transaction-capable connection")
		}
		transaction, err = capable.BeginTx(ctx, pgx.TxOptions{IsoLevel: pgx.ReadCommitted})
	}
	if err != nil {
		return 0, err
	}
	committed := false
	defer func() {
		if !committed {
			_ = transaction.Rollback(context.Background())
		}
	}()
	if err := pgAdmitMigrationTransaction(ctx, transaction, connection, true); err != nil {
		return 0, err
	}
	if _, err := transaction.Exec(ctx,
		`select pg_advisory_xact_lock(hashtextextended(current_database() || ':' || $1, 0))`,
		connection.QualifiedTable(pubsubOutboxTable)); err != nil {
		return 0, err
	}
	table := connection.QualifiedTable(pubsubOutboxTable)
	statement := `with pending as materialized (` +
		`select "id" from ` + table + ` where "dispatch_seq" is null order by "id" limit $1) ` +
		`update ` + table + ` as outbox set ` +
		`"dispatch_seq" = nextval($2::regclass), "dispatched_at" = clock_timestamp() ` +
		`from pending where outbox."id" = pending."id" and outbox."dispatch_seq" is null`
	tag, err := transaction.Exec(ctx, statement, int32(pubsubSweepBatch),
		connection.QualifiedTable(pubsubDispatchSeq))
	if err != nil {
		return 0, err
	}
	if err := transaction.Commit(ctx); err != nil {
		return 0, err
	}
	committed = true
	return int(tag.RowsAffected()), nil
}

type pubsubDrainStats struct {
	iterations       int
	legacyChecks     int
	dispatchQueries  int
	fetchQueries     int
	legacyRows       int
	rowsRead         int
	maxLegacyBatch   int
	maxDeliveryBatch int
}

// drainWithStats continuously catches up. Each iteration has bounded SQL and memory, and a full
// iteration yields before continuing; there is no periodic per-sweep ceiling that can turn a
// sustained but serviceable publish rate into permanent backlog.
func (runtime *pgPubsub) drainWithStats(conn *pgx.Conn, connection *PostgresDB) (pubsubDrainStats, error) {
	runtime.deliveryMutex.Lock()
	defer runtime.deliveryMutex.Unlock()
	stats := pubsubDrainStats{}
	for {
		if err := runtime.ctx.Err(); err != nil {
			return stats, err
		}
		ctx, cancel := context.WithTimeout(runtime.ctx, pgLeaseTimeout())
		batch, err := pgMigrationStatementOn(ctx, connection, conn, false, func(executor pgExecutor) ([]pubsubRow, error) {
			rows, err := executor.Query(ctx, `select "id", "channel", "key", "payload"::text, "dispatch_seq" from `+
				connection.QualifiedTable(pubsubOutboxTable)+
				` where "dispatch_seq" > $1 order by "dispatch_seq" limit $2`,
				runtime.cursor(), pubsubSweepBatch)
			if err != nil {
				return nil, err
			}
			return pgx.CollectRows(rows, func(row pgx.CollectableRow) (pubsubRow, error) {
				var collected pubsubRow
				err := row.Scan(&collected.id, &collected.channel, &collected.key, &collected.encoded,
					&collected.dispatchSequence)
				return collected, err
			})
		})
		stats.fetchQueries++
		cancel()
		if err != nil {
			return stats, err
		}
		stats.iterations++
		stats.rowsRead += len(batch)
		if len(batch) > stats.maxDeliveryBatch {
			stats.maxDeliveryBatch = len(batch)
		}
		for _, row := range batch {
			runtime.deliver(row.channel, row.key, row.encoded)
			runtime.advance(row.dispatchSequence)
		}
		if len(batch) == pubsubSweepBatch {
			goruntime.Gosched()
			continue
		}

		ctx, cancel = context.WithTimeout(runtime.ctx, pgLeaseTimeout())
		legacyPending, err := pgMigrationStatementOn(ctx, connection, conn, false, func(executor pgExecutor) (bool, error) {
			var pending bool
			err := executor.QueryRow(ctx, `select exists (select 1 from `+connection.QualifiedTable(pubsubOutboxTable)+` where "dispatch_seq" is null)`).Scan(&pending)
			return pending, err
		})
		cancel()
		stats.legacyChecks++
		if err != nil {
			return stats, err
		}
		if !legacyPending {
			return stats, nil
		}

		ctx, cancel = context.WithTimeout(runtime.ctx, pgLeaseTimeout())
		dispatched, err := dispatchLegacyPubsubPending(ctx, conn, connection)
		cancel()
		stats.dispatchQueries++
		if err != nil {
			return stats, err
		}
		stats.legacyRows += dispatched
		if dispatched > stats.maxLegacyBatch {
			stats.maxLegacyBatch = dispatched
		}
		goruntime.Gosched()
	}
}

func (runtime *pgPubsub) drain(conn *pgx.Conn, connection *PostgresDB) error {
	_, err := runtime.drainWithStats(conn, connection)
	return err
}

// prune deletes rows past the retention. Every instance prunes; the statement is idempotent
// and cheap, and electing one pruner would be a coordination problem for no gain.
func (runtime *pgPubsub) prune(conn *pgx.Conn, connection *PostgresDB) error {
	ctx, cancel := context.WithTimeout(runtime.ctx, pgLeaseTimeout())
	defer cancel()
	_, err := pgMigrationStatementOn(ctx, connection, conn, true, func(executor pgExecutor) (struct{}, error) {
		_, err := executor.Exec(ctx, `delete from `+connection.QualifiedTable(pubsubOutboxTable)+
			` where "dispatched_at" < now() - make_interval(secs => $1)`, pubsubOutboxRetention.Seconds())
		return struct{}{}, err
	})
	return err
}

// listenerPID answers the backend process id of the live LISTEN connection, or zero between
// connections — what a test needs to kill it.
// ListenerPID is the backend pid of this process's LISTEN connection (0 while disconnected);
// exported for the runtime's own tests, which terminate it to exercise the reconnect.
func (runtime *pgPubsub) ListenerPID() uint32 {
	runtime.mutex.Lock()
	defer runtime.mutex.Unlock()
	if runtime.listener == nil {
		return 0
	}
	return runtime.listener.PgConn().PID()
}

// close ends the listener goroutine and forgets the runtime, for a test that stood one up.
// A program never calls it: the listener lives as long as the process.
// Close stops the LISTEN loop and waits for it; exported for the runtime's own tests.
func (runtime *pgPubsub) Close() {
	runtime.cancel()
	pgPubsubs.CompareAndDelete(runtime.database, runtime)
	select {
	case <-runtime.done:
	case <-time.After(2 * pgLeaseTimeout()):
	}
}
