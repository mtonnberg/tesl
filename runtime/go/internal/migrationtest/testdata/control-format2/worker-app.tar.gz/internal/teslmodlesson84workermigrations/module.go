package teslmodlesson84workermigrations

import (
	"github.com/jackc/pgx/v5"
	"net/http"
	"tesl.generated/teslmodlesson84workermigrations/internal/teslmodworkernotesschemavcurrentnotes"
	"tesl.generated/teslmodlesson84workermigrations/internal/teslrt"
)

//line lesson84-worker-migrations.tesl:123
type NewNote struct {
	Title string
}

//line lesson84-worker-migrations.tesl:136
type NoteReply struct {
	Id    string
	Title string
}

//line lesson84-worker-migrations.tesl:93
var NoteDatabaseDatabase = teslrt.NewDatabase(
	"NoteDatabase",
	teslrt.PostgresConfig{DBName: teslrt.EnvString("NOTES_DB_NAME", ""), User: teslrt.EnvString("NOTES_DB_USER", ""), Password: teslrt.EnvString("NOTES_DB_PASSWORD", ""), Host: teslrt.EnvString("NOTES_DB_HOST", ""), Port: teslrt.PgPort("NOTES_DB_PORT", 5432), ControlOwner: teslrt.EnvString("NOTES_CONTROL_OWNER", ""), MigrationTopology: "Worker", RequestRole: teslrt.EnvString("NOTES_REQUEST_ROLE", ""), WorkerRole: teslrt.EnvString("NOTES_WORKER_ROLE", ""), Schema: "worker_notes"},
	[]teslrt.PostgresTable{
		teslrt.PostgresTableOf("lesson_worker_notes",
			teslrt.PostgresColumnOf("id", "TEXT", true, false),
			teslrt.PostgresColumnOf("title", "TEXT", false, false),
		),
	},
)

var _ = teslrt.RegisterDatabaseIdentity("teslmodlesson84workermigrations.NoteDatabase", NoteDatabaseDatabase)

var _ = teslrt.RegisterDatabaseMigrationHistory(NoteDatabaseDatabase, "WorkerNotesSchema")

//line lesson84-worker-migrations.tesl:110
func SaveTitle(id string, raw string) bool {
//line lesson84-worker-migrations.tesl:111
	{
		teslScrut1 := teslmodworkernotesschemavcurrentnotes.TryTitle(raw)
		switch teslScrut1.Tag {
		case teslrt.MaybeNothing:
//line lesson84-worker-migrations.tesl:112
			return false
		case teslrt.MaybeSomething:
			title := teslScrut1.SomethingValue
			_ = title
			{
//line lesson84-worker-migrations.tesl:114
				notes := []teslmodworkernotesschemavcurrentnotes.Note{teslmodworkernotesschemavcurrentnotes.NewNote(id, title)}
				_ = notes
				{
//line lesson84-worker-migrations.tesl:115
					_ = teslrt.DbInsertMany(teslrt.ResolveDatabaseIdentity("teslmodlesson84workermigrations.NoteDatabase"), teslmodworkernotesschemavcurrentnotes.NoteTable, "Note", notes, func(teslRow, teslNew teslmodworkernotesschemavcurrentnotes.Note) bool { return (teslRow.Id == teslNew.Id) }, "insert into \"worker_notes\".\"lesson_worker_notes\" (\"id\", \"title\") values ($1, $2)", func(teslRow teslmodworkernotesschemavcurrentnotes.Note) []any {
						return []any{teslRow.Id, teslRow.Title}
					})
//line lesson84-worker-migrations.tesl:116
					return true
				}
			}
		default:
			panic("unreachable: checker guarantees case exhaustiveness")
		}
	}
}

//line lesson84-worker-migrations.tesl:118
func FindTitle(id string) teslrt.Maybe[string] {
//line lesson84-worker-migrations.tesl:119
	{
		teslScrut1 := teslrt.DbSelectOne(teslrt.ResolveDatabaseIdentity("teslmodlesson84workermigrations.NoteDatabase"), teslmodworkernotesschemavcurrentnotes.NoteTable, func(note teslmodworkernotesschemavcurrentnotes.Note) bool {
			return (note.Id == id)
		}, nil, teslrt.PgSql("select \"id\", \"title\" from \"worker_notes\".\"lesson_worker_notes\" where \"id\" = $1 limit 1", func() []any {
			return []any{id}
		}), teslScanNote)
		switch teslScrut1.Tag {
		case teslrt.MaybeNothing:
//line lesson84-worker-migrations.tesl:120
			return teslrt.Maybe[string]{Tag: teslrt.MaybeNothing}
		case teslrt.MaybeSomething:
			note := teslScrut1.SomethingValue
			_ = note
//line lesson84-worker-migrations.tesl:121
			return teslrt.Maybe[string]{Tag: teslrt.MaybeSomething, SomethingValue: note.Title}
		default:
			panic("unreachable: checker guarantees case exhaustiveness")
		}
	}
}

//line lesson84-worker-migrations.tesl:151
func createNote(id string, body NewNote) NoteReply {
//line lesson84-worker-migrations.tesl:153
	if SaveTitle(id, body.Title) {
//line lesson84-worker-migrations.tesl:154
		{
			teslScrut2 := FindTitle(id)
			switch teslScrut2.Tag {
			case teslrt.MaybeNothing:
//line lesson84-worker-migrations.tesl:155
				panic(teslrt.RequestRejection{Status: 404, Message: "note not found"})
			case teslrt.MaybeSomething:
				title := teslScrut2.SomethingValue
				_ = title
//line lesson84-worker-migrations.tesl:156
				return NoteReply{Id: id, Title: title}
			default:
				panic("unreachable: checker guarantees case exhaustiveness")
			}
		}
	} else {
//line lesson84-worker-migrations.tesl:158
		panic(teslrt.RequestRejection{Status: 400, Message: "title must be 1-80 characters after trimming"})
	}
}

//line lesson84-worker-migrations.tesl:160
func getNote(id string) NoteReply {
//line lesson84-worker-migrations.tesl:161
	{
		teslScrut1 := FindTitle(id)
		switch teslScrut1.Tag {
		case teslrt.MaybeNothing:
//line lesson84-worker-migrations.tesl:162
			panic(teslrt.RequestRejection{Status: 404, Message: "note not found"})
		case teslrt.MaybeSomething:
			title := teslScrut1.SomethingValue
			_ = title
//line lesson84-worker-migrations.tesl:163
			return NoteReply{Id: id, Title: title}
		default:
			panic("unreachable: checker guarantees case exhaustiveness")
		}
	}
}

//line lesson84-worker-migrations.tesl:182
func Main() struct{} {
//line lesson84-worker-migrations.tesl:182
	return func() struct{} {
		var teslBound struct{}
		teslrt.WithDatabase(NoteDatabaseDatabase, func() {
			teslBound = teslrt.Serve(NotesServer, teslrt.ServeOptions{Port: teslrt.PortOf(teslrt.EnvInt("NOTES_HTTP_PORT", teslrt.FromInt64(8084))), ListenAddress: "127.0.0.1"})
		})
		return teslBound
	}()
}

func teslDecodeNewNoteAlt0(teslJSON any) teslrt.Check[NewNote] {
	teslFieldTitle, teslErrTitle := teslrt.DecodeStringField(teslJSON, "title")
	if teslErrTitle != nil {
		return teslrt.RejectShape[NewNote](teslErrTitle.Error())
	}
	teslDecoded := NewNote{Title: teslFieldTitle}
	return teslrt.Accept(teslDecoded)
}

func DecodeNewNoteJSON(teslJSON any) teslrt.Check[NewNote] {
	var teslFirstFailure teslrt.Check[NewNote]
	teslHaveFailure := false
	teslResult0 := teslDecodeNewNoteAlt0(teslJSON)
	if teslResult0.OK() {
		return teslResult0
	}
	if !teslResult0.IsShapeMismatch() && !teslHaveFailure {
		teslFirstFailure = teslResult0
		teslHaveFailure = true
	}
	if teslHaveFailure {
		return teslFirstFailure
	}
	return teslrt.Reject[NewNote](400, "no decode alternative matched")
}

func EncodeNoteReplyJSON(teslValue NoteReply) any {
	return map[string]any{
		"id":    teslValue.Id,
		"title": teslValue.Title,
	}
}

var NotesServer = teslrt.Server{
	Routes: []teslrt.Route{
		{Method: "POST", Path: "/notes/:id", Endpoint: "createNote"},
		{Method: "GET", Path: "/notes/:id", Endpoint: "getNote"},
	},
	Handlers: map[string]teslrt.HandlerFunc{
		"createNote": func(teslScope *teslrt.RequestScope, teslRequest *http.Request) teslrt.Response {
			_ = teslScope
			teslBodyBytes, teslBodyStatus, teslBodyMessage := teslrt.ReadRequestBody(teslRequest)
			if teslBodyStatus != 0 {
				return teslrt.Fail(teslBodyStatus, teslBodyMessage)
			}
			id, teslFoundId := teslrt.PathParam("/notes/:id", teslRequest.URL.Path, "id")
			if !teslFoundId {
				return teslrt.Fail(404, "not found")
			}
			if teslStatus, teslMessage := teslrt.CheckJSONPayload(teslRequest, teslBodyBytes); teslStatus != 0 {
				return teslrt.Fail(teslStatus, teslMessage)
			}
			teslParsed, teslParseErr := teslrt.ParseJSON(teslBodyBytes)
			if teslParseErr != nil {
				return teslrt.Fail(400, "Malformed JSON payload")
			}
			teslDecoded := DecodeNewNoteJSON(teslParsed)
			if !teslDecoded.OK() {
				return teslrt.Fail(teslDecoded.Status(), teslDecoded.Message())
			}
			teslBody, _ := teslDecoded.Value()
			return teslrt.Response{Status: 200, Body: EncodeNoteReplyJSON(createNote(id, teslBody))}
		},
		"getNote": func(teslScope *teslrt.RequestScope, teslRequest *http.Request) teslrt.Response {
			_ = teslScope
			id, teslFoundId := teslrt.PathParam("/notes/:id", teslRequest.URL.Path, "id")
			if !teslFoundId {
				return teslrt.Fail(404, "not found")
			}
			_ = teslRequest
			return teslrt.Response{Status: 200, Body: EncodeNoteReplyJSON(getNote(id))}
		},
	},
}

func teslScanNote(teslRow pgx.CollectableRow) (teslmodworkernotesschemavcurrentnotes.Note, error) {
	teslValue := teslmodworkernotesschemavcurrentnotes.Note{}
	var teslColumn0 string
	var teslColumn1 string
	if teslErr := teslRow.Scan(&teslColumn0, &teslColumn1); teslErr != nil {
		return teslValue, teslErr
	}
	teslValue.Id = teslColumn0
	teslValue.Title = teslColumn1
	return teslValue, nil
}

// Declared in Tesl but not called within this module.  Tesl permits an unused
// private declaration; Go's linters do not, so these references keep them.
var (
	_ = Main
	_ = createNote
	_ = getNote
)
