package teslmodworkernotesschemavcurrentnotes

import "tesl.generated/teslmodlesson84workermigrations/internal/teslrt"

//line notes.tesl:31
type Note struct {
	Id    string
	Title string
}

//line notes.tesl:31
var NoteTable = teslrt.NewTable[Note]()

//line notes.tesl:20
func titleLimit() teslrt.Int {
//line notes.tesl:20
	return teslrt.FromInt64(80)
}

//line notes.tesl:24
func TryTitle(raw string) teslrt.Maybe[string] {
	{
//line notes.tesl:25
		title := teslrt.StringTrim(raw)
		_ = title
//line notes.tesl:26
		if (teslrt.Compare(teslrt.StringLength(title), teslrt.FromInt64(0)) > 0) && (teslrt.Compare(teslrt.StringLength(title), titleLimit()) <= 0) {
//line notes.tesl:27
			return teslrt.Maybe[string]{Tag: teslrt.MaybeSomething, SomethingValue: title}
		} else {
//line notes.tesl:29
			return teslrt.Maybe[string]{Tag: teslrt.MaybeNothing}
		}
	}
}

//line notes.tesl:38
func NewNote(id string, title string) Note {
//line notes.tesl:39
	return Note{Id: id, Title: title}
}
